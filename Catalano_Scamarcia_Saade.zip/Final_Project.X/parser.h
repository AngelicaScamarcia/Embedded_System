/*
 * File:   parser.h 
 * 
 * Author: Alice Maria Catalano(5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 *
 */

#ifndef PARSER_H
#define	PARSER_H

#define STATE_DOLLAR  (1)                                                       // Discard everything until a dollar is found
#define STATE_TYPE    (2)                                                       // Reading the type of msg until a comma is found
#define STATE_PAYLOAD (3)                                                       // Read the payload until an asterix is found
#define NEW_MESSAGE (1)                                                         // New message received and parsed completely
#define NO_MESSAGE (0)                                                          // No new messages
#define PARSE_ERROR (-1)                                                        // Error occourred in any parsing step

typedef struct { 
	int state;
	char msg_type[6]; 
	char msg_payload[100]; 
	int index_type;
	int index_payload;
} parser_state;


int parse_byte(parser_state* ps, char byte);
//float extract_float(const char* str);
int extract_message(const char* str, int *n1, int *n2);
int extract_integer(const char* str, int* n);

#endif	/* PARSER_H */

