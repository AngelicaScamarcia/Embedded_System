/*
 * File:   main.c
 *
 * Author: Alice Maria Catalano(5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 *
 */

// DSPIC30F4011 Configuration Bit Settings

// 'C' source line config statements

// FOSC
#pragma config FPR = XT                 // Primary Oscillator Mode (XT)
#pragma config FOS = PRI                // Oscillator Source (Primary Oscillator)
#pragma config FCKSMEN = CSW_FSCM_OFF   // Clock Switching and Monitor (Sw Disabled, Mon Disabled)

// FWDT
#pragma config FWPSB = WDTPSB_16        // WDT Prescaler B (1:16)
#pragma config FWPSA = WDTPSA_512       // WDT Prescaler A (1:512)
#pragma config WDT = WDT_OFF            // Watchdog Timer (Disabled)

// FBORPOR
#pragma config FPWRT = PWRT_64          // POR Timer Value (64ms)
#pragma config BODENV = BORV20          // Brown Out Voltage (Reserved)
#pragma config BOREN = PBOR_ON          // PBOR Enable (Enabled)
#pragma config LPOL = PWMxL_ACT_HI      // Low-side PWM Output Polarity (Active High)
#pragma config HPOL = PWMxH_ACT_HI      // High-side PWM Output Polarity (Active High)
#pragma config PWMPIN = RST_IOPIN       // PWM Output Pin Reset (Control with PORT/TRIS regs)
#pragma config MCLRE = MCLR_EN          // Master Clear Enable (Enabled)

// FGS
#pragma config GWRP = GWRP_OFF          // General Code Segment Write Protect (Disabled)
#pragma config GCP = CODE_PROT_OFF      // General Segment Code Protection (Disabled)

// FICD
#pragma config ICS = ICS_PGD            // Comm Channel Select (Use PGC/EMUC and PGD/EMUD)

#include <xc.h>
#include <p30F4011.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.h"
#include "scheduler.h"
#include "timer.h"
#include "spi.h"

#define FIRST_ROW 0
#define SECOND_ROW 1
#define BUFFER_SIZE_IN 26                                                        //the message is 11 char, but if the user inserts 1000 goes to 12
#define BUFFER_SIZE_OUT 28  
#define WHEEL_DISTANCE 0.5                                                      // distance between wheels, in meters
#define WHEEL_RADIUS 0.2

// Flags initializaions & global variables
short int safe_mode = 0;
volatile int flag_mcAle = 0;
volatile int timeout_flag = 0;
volatile int safeMode_flag = 0;
volatile int s6_flag = 0;
volatile int success_flag = 1;

volatile float avarage = 0;
volatile char temp_array[10];
volatile int temp_array_index = 0;

typedef struct {
    int size;
    int readIndex;
    int writeIndex;
    char* buffer;
} CircularBuffer;
volatile CircularBuffer circularBuffer;
volatile CircularBuffer cb_output;

void write_buffer(volatile CircularBuffer* cb, char value) {
    cb ->buffer[ cb -> writeIndex] = value;
    cb -> writeIndex = (cb -> writeIndex + 1) % cb->size;                       // If the writeIndex goes to 26 or 28, it will be not allowed and it will go back to 0
    if (cb -> readIndex == cb -> writeIndex) {
        //full buffer mode
        cb ->readIndex++;                                                       // Discard the last byte
    }
    
}

int read_buffer(volatile CircularBuffer* cb, char* value) {
    if (cb -> readIndex != cb -> writeIndex) {
        *value = cb -> buffer[cb -> readIndex];
        cb -> readIndex = (cb->readIndex + 1) % cb->size;
        return 0;
    }
    else{
        return -1;
    }
}

int avl_bytes_cb(volatile CircularBuffer* cb) {                                 // To check how many bytes are busy in the buffer
    if (cb -> readIndex <= cb -> writeIndex) {                                  // Might give problems with interrupts on one of the indexes
        return cb->writeIndex - cb -> readIndex;                                // If the readInd is less than the writeInd , then the number of bytes is the difference between them
    } else {
        return cb->size - cb ->readIndex + cb->writeIndex;
    }
}

// Function to calculate the desired RPMs of the wheels
void calculateDesiredRPM(int omega, int speed, float* right, float* left) {
    const float pi = 3.14;
    *left = (speed - (omega * (WHEEL_DISTANCE / 2))) / (2 * pi * WHEEL_RADIUS);
    *right = (speed + omega * WHEEL_DISTANCE / 2) / (2 * pi * WHEEL_RADIUS);

}

void set_MotorRPM(float* rpm) {
    if (*rpm > 50.0) {
        *rpm = 50.0;
    } else if (*rpm<-50.0) {
        *rpm = -50.0;
    }
}


//ADC setup
void adc_config() {
    //ADC configuration
    ADCON3bits.ADCS = 8;                                                        // Tad

    ADCON1bits.ASAM = 1;                                                        // Automatic sampling
    ADCON1bits.SSRC = 7;                                                        // Automatic conversion 

    ADCON3bits.SAMC = 1;                                                        // Fixed conversion time (only if SSRC = 7)

    ADCON2bits.CHPS = 0; 
    
    ADCHSbits.CH0SA = 3;                                                        // Use AN3 connected to CH0
    ADCHSbits.CH0NA = 0;                                                        //AN2 to ground

    ADPCFG = 0xFFFF;
    ADPCFGbits.PCFG3 = 0;
    //Turn on
    ADCON1bits.ADON = 1;
}

//Scheduler
void scheduler_config() {
    schedInfo[0].n = 0;
    schedInfo[0].N = 1;                                                         // Heartbeat 10Hz = 100ms
    schedInfo[1].n = 0;
    schedInfo[1].N = 2;                                                         // Task2 5Hz=200ms, 100*2= 200 ms
    schedInfo[2].n = 0;
    schedInfo[2].N = 10;                                                        // Task3 1Hz=1000ms 100*10= 1000 ms
    schedInfo[3].n = 0;
    schedInfo[3].N = 5;                                                         // Task4 1Hz led blinking
}

//ISF for UART2 receiving
void __attribute__((__interrupt__, __auto_psv__)) _U2RXInterrupt() {            // Receiver interrupt
    IFS1bits.U2RXIF = 0;
    while (U2STAbits.URXDA == 1) {
        write_buffer(&circularBuffer, U2RXREG);
    }
    if (U2STAbits.OERR == 1) {
        success_flag = 0;
    }
}

//ISF for UART2 transmitting
void __attribute__((__interrupt__, __auto_psv__)) _U2TXInterrupt() {
    IFS1bits.U2TXIF = 0;

    int available_bytes_output = avl_bytes_cb(&cb_output);
    char feedback;

    while (U2STAbits.UTXBF != 1 && available_bytes_output != 0) {
        if (read_buffer(&cb_output, &feedback)==0){
            U2TXREG = feedback;
            
        }
        else{
            //error in reading
            success_flag = 0;
        }
        available_bytes_output = avl_bytes_cb(&cb_output);
    }
}

//ISF TIMER1 timeout
void __attribute__((__interrupt__, __auto_psv__)) _T1Interrupt(){
    T1CONbits.TON = 0;                                                          // Stop the TIMER1 
    IFS0bits.T1IF = 0;                                                          // Timer interrupt flag down
    
    timeout_flag = 1;                                                           // Timeout mode
}

//ISF TIMER2 
void __attribute__((__interrupt__, __auto_psv__)) _T2Interrupt(){
    
    T2CONbits.TON = 0;                                                          // Stop the TIMER2 
    IFS0bits.T2IF = 0;                                                          // Flag down of timer Interrupt 
    
    IFS0bits.INT0IF = 0;                                                        // Flag down of ISF button S5
    IFS1bits.INT1IF = 0;                                                        // Flag down of ISF button S6
    IEC0bits.INT0IE = 1;                                                        // Enable ISF button S5
    IEC1bits.INT1IE = 1;                                                        // Enable ISF button S6
}

//ISF for button S5 pressing
void __attribute__((__interrupt__, __auto_psv__)) _INT0Interrupt(){
    IFS0bits.INT0IF = 0;                                                        // Setting the Interrupt down  
    
    //Enable safe mode
    PDC1 = PDC2 = PTPER;
    
    safeMode_flag = 1;
    flag_mcAle = 0;
    motor_data.omega = 0;
    motor_data.speed = 0;
    motor_data.left_rpm = motor_data.sat_left_rpm = 0;
    motor_data.right_rpm = motor_data.sat_right_rpm = 0;
    
    
    tmr_setup_period(TIMER2,100);                                               // Deleting bouncing effect 
    IEC0bits.INT0IE = 0;                                                        // Interrupt on S5 flag down
    IEC0bits.T2IE = 1;                                                          // Enable interrupt on TIMER2
}

//ISF for button S6 pressing
void __attribute__((__interrupt__, __auto_psv__)) _INT1Interrupt(){
    
    IFS1bits.INT1IF = 0;                                                        // Setting the Interrupt down
    s6_flag = !s6_flag; 
    
    tmr_setup_period(TIMER2,100);                                               // Deleting bouncing effect
    IEC1bits.INT1IE = 0;                                                        // Interrupt on S6 flag down
    IEC0bits.T2IE = 1;                                                          // Enable interrupt on TIMER2
}

//Task 1 10Hz
wheel_RPMs send_to_micro(parser_state* pstate, wheel_RPMs motor_data) {
    int available_bytes;

    IEC1bits.U2RXIE = 0;                                                        // Protecting the function from the interrupts
    available_bytes = avl_bytes_cb(&circularBuffer);                            // Compute how many data in the buffer
    IEC1bits.U2RXIE = 1;

    int count = 0;
    while (count < available_bytes) {
        char byte;

        if(read_buffer(&circularBuffer, &byte)!=0){
            // Error in reading
            success_flag = 0;
        }                                                                       // Bytes that I can give to the parser

        int ret = parse_byte(pstate, byte);
        if (ret == NEW_MESSAGE) {                                               // Check the arrival of a complete message
            // Value going from -999 to 999
            //The PC sends $HLREF,omega,speed*, where RPM is a value going from 0 to 1000
            if (strcmp(pstate->msg_type, "HLREF") == 0 && safeMode_flag == 0) {
                success_flag = 1;
                if (extract_message(pstate->msg_payload, &motor_data.omega, &motor_data.speed) == 0) {
                    success_flag = 1;
                    timeout_flag = 0;                                           // Reset timeout_flag
                    tmr_setup_period(TIMER1,5000);
                    
                    calculateDesiredRPM(motor_data.omega, motor_data.speed, &motor_data.right_rpm, &motor_data.left_rpm);
                    
                    if (motor_data.left_rpm < -50 || motor_data.left_rpm > 50 || motor_data.right_rpm < -50 || motor_data.right_rpm > 50) {
                        // Out of range, saturate
                        flag_mcAle = 1;
                        motor_data.sat_left_rpm = motor_data.left_rpm;
                        motor_data.sat_right_rpm = motor_data.right_rpm;
                        set_MotorRPM(&motor_data.sat_left_rpm);
                        set_MotorRPM(&motor_data.sat_right_rpm);
                        
                        double duty_cycle_l = ((motor_data.sat_left_rpm - (-60)) / (60 - (-60))) *100;
                        PDC1 = duty_cycle_l * 2 * PTPER;
                        double duty_cycle_r = ((motor_data.sat_right_rpm - (-60)) / (60 - (-60))) *100;
                        PDC2 = duty_cycle_r * 2 * PTPER;
                    } else {
                        // NO saturation
                        motor_data.sat_left_rpm = motor_data.left_rpm;
                        motor_data.sat_right_rpm = motor_data.right_rpm;

                        flag_mcAle = 0;
                        
                        double duty_cycle_l = ((motor_data.left_rpm - (-60)) / (60 - (-60))) *100;
                        PDC1 = duty_cycle_l * 2 * PTPER;
                        double duty_cycle_r = ((motor_data.right_rpm - (-60)) / (60 - (-60))) *100;
                        PDC2 = duty_cycle_r * 2 * PTPER;
                    }
                }
                else{
                    // Error in extracting the message
                    success_flag = 0;
                }
                
            }
            
            //$HLENA* enables the firmware to send references to the motors (to exit safe mode) 
            else if (strcmp(pstate->msg_type, "HLENA") == 0){
                success_flag = 1;
                safeMode_flag = 0;
                timeout_flag = 0;
                motor_data.omega = 0;
                motor_data.speed = 0;
                motor_data.sat_left_rpm = motor_data.left_rpm = 0;
                motor_data.sat_right_rpm = motor_data.right_rpm = 0;
                PDC1 = PDC2 = PTPER;
                //$MCACK,msg_type,value* where msg_type is the command (e.g. ENA), and and value is 1  
                char msg_type[25] = "$MCACK,ENA,1*";
                send_to_pc(msg_type);
            }
        }
        else{
            success_flag = 0;
        }
        count++;
    }
    if (timeout_flag ==1){
        success_flag = 1;
        LATBbits.LATB1 = !LATBbits.LATB1;
        flag_mcAle = 0;
        motor_data.omega = 0;
        motor_data.speed = 0;
        motor_data.sat_left_rpm = motor_data.left_rpm = 0;
        motor_data.sat_right_rpm = motor_data.right_rpm = 0;
        PDC1 = PDC2 = PTPER;
    }
    else {
        LATBbits.LATB1=0;
    }
    ADCON1bits.SAMP = 1;                                                        // Start sampling
    while(ADCON1bits.DONE == 0); 
    int adcValueTemp = ADCBUF0;
    double TempVolt = adcValueTemp / 1024.0 * 5.0;
    double temperature = (TempVolt -0.75) * 100 + 25;
    add_temperature_value(temperature);
    
    //Display on LCD 
    //First row: $STATUS: x*, where x = H/T/C (halt/timeout/controlled)
    char status_print[8];
    char state = 'C';
    if (safeMode_flag == 1){
        state = 'H';
    }
    else if (timeout_flag == 1){
        state = 'T';
    }
    else{
        state = 'C';
    }
    sprintf(status_print, "STATUS: %c", state);
    clear_LCD_firstRow();
    move_cursor(FIRST_ROW, 0);
    write_string_LCD(status_print);
    
    //Second row: $R: n1; n2*, where n1 and n2 are the applied RPM (e.g. ?R: -20; 33?)
    char rpm_print[17];
    if(s6_flag == 0){
        sprintf(rpm_print, "R: %.1f,%.1f", motor_data.sat_left_rpm, motor_data.sat_right_rpm);
        clear_LCD_secondRow();
        move_cursor(SECOND_ROW, 0);
        write_string_LCD(rpm_print);
    }
    else{
        sprintf(rpm_print, "R: %d,%d", motor_data.omega, motor_data.speed);
        clear_LCD_secondRow();
        move_cursor(SECOND_ROW,0);
        write_string_LCD(rpm_print);
    }
    
    return motor_data;
}

void add_temperature_value(double value) {
    
    if(temp_array_index < 10){
        temp_array[temp_array_index] = value;
        temp_array_index++;
    }
    else{
        temp_array_index = 0;
        temp_array[temp_array_index] = value;
        temp_array_index++;
    }
    float sum = 0;
    for (int i = 0; i < 10; i++) {
            sum += temp_array[i];
        }
    avarage = sum / 10;
    
    
}

//Task 2 5Hz
void task2(wheel_RPMs motor_data){
    // $MCFBK,n1,n2,state* where n1 and n2 are the applied RPM values and state is 2 if the 
    // microcontroller is in safe mode, 1 if it is in timeout mode, 0 otherwise.
    char status[3];
    int state = 0;

    if(safeMode_flag == 1){
        state = 2;
        sprintf(status, ",%d", state);
        LATBbits.LATB1=0;
    }
    else if (timeout_flag ==1){
        state = 1;
        sprintf(status, ",%d", state);
    }
    else {
        sprintf(status, ",%d", state);
    }
    char msg_type[25] = "$MCFBK,";
    char str[17]; //strings to print
    sprintf(str, "%.1f,%.1f", motor_data.left_rpm, motor_data.right_rpm);
    strcat(msg_type, str);
    strcat(msg_type, status);
    strcat(msg_type, "*");
    send_to_pc(msg_type);
}

//Task 3 1Hz
void task3(wheel_RPMs motor_data) {
    if (flag_mcAle ==1){
        // Build the message for the UART   $MCFBK,CURRENT,TEMP* 
        char msg_type[25] = "$MCALE,";
        char str[17]; //strings to print
        sprintf(str, "%.1f,%.1f", motor_data.left_rpm, motor_data.right_rpm);
        strcat(msg_type, str);
        strcat(msg_type, "*");
    
        send_to_pc(msg_type);
    }
    //$MCTEM,temp* where temp is the temperature
    char msg_type_temp[25] = "$MCTEM,";
    char str[17];                                                               //  Strings to print
    sprintf(str, "%.1f",avarage);
    strcat(msg_type_temp, str);
    strcat(msg_type_temp, "*");
    
    send_to_pc(msg_type_temp);
    
    
}

//Task 4 blink led D3
void task4(){
    if(success_flag == 1){
        LATBbits.LATB0 = !LATBbits.LATB0;
    }else{
        LATBbits.LATB0 = 0;
    }
}

void send_to_pc(char* to_send) {
    int available_bytes_output;
    IEC1bits.U2TXIE = 0;                                                        // Protecting the function from the interrupts
    available_bytes_output = BUFFER_SIZE_OUT - avl_bytes_cb(&cb_output);        // Compute how many data are free in the buffer
    IEC1bits.U2TXIE = 1;
        
    char feedback;

    if (strlen(to_send) < available_bytes_output) {
        for (int i = 0; to_send[i] != '\0'; i++){ 
            write_buffer(&cb_output, to_send[i]);
        }
        IEC1bits.U2TXIE = 0;
        while (U2STAbits.UTXBF == 0) {
            read_buffer(&cb_output, &feedback);
            U2TXREG = feedback;
        }
        IEC1bits.U2TXIE = 1;
    }
}

int main(void) {
    
    TRISBbits.TRISB0 = 0;
    TRISBbits.TRISB1 = 0;
    char bufIn[BUFFER_SIZE_IN];
    char bufOut[BUFFER_SIZE_OUT];
    
    // Initialize the circular buffers
    circularBuffer.size = BUFFER_SIZE_IN;
    circularBuffer.buffer = bufIn;
    circularBuffer.readIndex = 0;
    circularBuffer.writeIndex = 0;
    cb_output.buffer = bufOut;
    cb_output.size = BUFFER_SIZE_OUT;
    cb_output.readIndex = 0;
    cb_output.writeIndex = 0;

    adc_config();
    spi_config();
    tmr_wait_ms(TIMER4, 1000);
    // Baud rate
    U2BRG = 23;
    U2MODEbits.UARTEN = 1;
    U2STAbits.UTXEN = 1;
    U2STAbits.UTXISEL = 0b1; 
    U2STAbits.URXISEL = 0b00; 
    
    IEC1bits.U2RXIE = 1;                                                        // Receiving UART Interrupt enabled, data will arrive and put in the buffer
    IEC1bits.U2TXIE = 1;                                                        // Transmitting UART interrupt 
    IEC0bits.T1IE = 1;                                                          // Enable interrupt on timer1
    IEC0bits.INT0IE = 1;                                                        // Interrupt on button S5
    IEC1bits.INT1IE = 1;                                                        // Interrupt on button S6

    // PWM initialization
    PTCONbits.PTMOD = 0;                                                        // Free running
    PTCONbits.PTCKPS = 1;                                                       // 1:4 prescaler
    PWMCON1bits.PEN2H = 1;
    PWMCON1bits.PEN2L = 1;
    PWMCON1bits.PEN3H = 1; 
    PWMCON1bits.PEN3L = 1; 
    DTCON1bits.DTA=6;                                                           // Dead time 3ms
    DTCON1bits.DTAPS=0;                                                         //Dead time prescale
    
    PTPER = 9216;                                                               // Fcy/(4*50Hz)-1
    PDC1 = PDC2 = PTPER;                                                        // 50% = 0 rpms
    PTCONbits.PTEN = 1;

    // Parser initialization
    parser_state pstate;
    pstate.state = STATE_DOLLAR;
    pstate.index_type = 0;
    pstate.index_payload = 0;

    scheduler_config();
    tmr_setup_period(TIMER3, 100);

    while (1) {
        int i;
        for (i = 0; i < MAX_TASKS; i++) {
            schedInfo[i]. n++;
            if (schedInfo[i]. n >= schedInfo[i].N) {
                switch (i) {
                    case 0:
                        //read the rpm value and compute the ad conversion;
                        motor_data = send_to_micro(&pstate, motor_data);

                        break;
                    case 1:
                        //task2();
                        task2(motor_data);
                        break;
                    case 2:
                        task3(motor_data);
                        break;
                    case 3:
                        task4();
                        break;
                  
                }
                schedInfo[i]. n = 0;
            }
        }
        tmr_wait_period(TIMER3);
    }
    return 0;
}

