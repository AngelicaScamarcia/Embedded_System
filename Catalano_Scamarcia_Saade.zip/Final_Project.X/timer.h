/* 
 * File:   timer.h
 * 
 * Author: Alice Maria Catalano(5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 *
 */

#ifndef TIMER_H
#define	TIMER_H

#define TIMER1 1
#define TIMER2 2 
#define TIMER3 3
#define TIMER4 4

//function to set and wait ms
void tmr_wait_ms(int timer, int ms);

//function used to set the prescaler
void choose_prescaler(int ms,int* pr,int* tckps);

//set the timer for ms
void tmr_setup_period(int timer, int ms);

//wait until the timer expires
void tmr_wait_period(int timer);

#endif	/* TIMER_H */

