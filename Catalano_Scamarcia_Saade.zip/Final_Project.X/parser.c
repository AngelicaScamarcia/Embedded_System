/*
 * File:   parser.c 
 * 
 * Author: Alice Maria Catalano(5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 *
 */
#include "parser.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>



int extract_integer(const char* str, int* n) {
    int i = 0, number = 0, sign = 1;
    if (str[i] == '-') {
        sign = -1;
        i++;
    } else if (str[i] == '+') {
        sign = 1;
        i++;
    }
    while (str[i] != ',' && str[i] != '\0') {
        if ((str[i] - '0') < 0 || (str[i] - '0') > 9)
            return -1;
        number *= 10; // multiply the current number by 10;
        number += str[i] - '0'; // converting character to decimal number
        i++;
    }
    *n = sign*number;
    return 0;
}

int parse_byte(parser_state* ps, char byte) {
    switch (ps->state) {
        case STATE_DOLLAR:
            if (byte == '$') {
                ps->state = STATE_TYPE;
                ps->index_type = 0;
            }
            break;
        case STATE_TYPE:
            if (byte == ',') {
                ps->state = STATE_PAYLOAD;
                ps->msg_type[ps->index_type] = '\0';
                ps->index_payload = 0; // initialize properly the index
            } else if (ps->index_type == 6) { // error! 
                ps->state = STATE_DOLLAR;
                ps->index_type = 0;
                return PARSE_ERROR;     //if you send more than 6bytes
			} else if (byte == '*') {
				ps->state = STATE_DOLLAR; // get ready for a new message
                ps->msg_type[ps->index_type] = '\0';
				ps->msg_payload[0] = '\0'; // no payload
                return NEW_MESSAGE;
            } else {
                ps->msg_type[ps->index_type] = byte; // ok!
                ps->index_type++; // increment for the next time;
            }
            break;
        case STATE_PAYLOAD:
            if (byte == '*') {
                ps->state = STATE_DOLLAR; // get ready for a new message
                ps->msg_payload[ps->index_payload] = '\0';
                return NEW_MESSAGE;
            } else if (ps->index_payload == 100) { // error
                ps->state = STATE_DOLLAR;
                ps->index_payload = 0;
                return PARSE_ERROR;
            } else {
                ps->msg_payload[ps->index_payload] = byte; // ok!
                ps->index_payload++; // increment for the next time;
            }
            break;
    }
    return NO_MESSAGE;
}

int extract_message(const char* str, int* n1, int* n2){
    int len= strlen(str);
    char string1[len];
    char string2[len];
    int i;
    int j=0;
    int flag =1;
    for(i=0;i<len+1; i++){
        if(str[i]==','){ 
            char string_to_send[i+1];
            int k=0;
            for(;k<i; k++){
                string_to_send[k]=string1[k];
            }
            string_to_send[i]='\0';

            flag= extract_integer(string_to_send, n1);

            if(flag==-1){
                return -1;
            }
            i++;
            j=i;
        }

        if(str[i]=='\0'){
           // char* string_to_send= string2;
            char string_to_send[i-j+1];
            int k=0;
            for(;k<i-j; k++){
                string_to_send[k]=string2[k];
            }
            string_to_send[i-j]='\0';
            flag= extract_integer(string_to_send, n2);

            if(flag==-1){
                return -1;
            }
        }
        if(flag==1){
            string1[i]=str[i];
        }
        else{
            string2[i-j]=str[i];
        }
    }

    return 0;
}

