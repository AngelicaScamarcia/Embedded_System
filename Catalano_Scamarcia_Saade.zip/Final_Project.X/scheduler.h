/* 
 * File:   scheduler.h
 * 
 * Author: Alice Maria Catalano(5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 *
 */

#ifndef SCHEDULER_H
#define	SCHEDULER_H

#define MAX_TASKS 4

typedef struct {
    int n;
    int N;
} heartbeat;
heartbeat schedInfo[MAX_TASKS];

typedef struct{
    double current;
    double temperature;
}data_sensors_t;
data_sensors_t data_sensors;

typedef struct {
  float left_rpm;
  float right_rpm;
  float sat_left_rpm;
  float sat_right_rpm;
  int omega;
  int speed;
} wheel_RPMs ;
wheel_RPMs motor_data;

void scheduler() ;
void scheduler_config();
void add_temperature_value(double value);
wheel_RPMs send_to_micro(parser_state* pstate, wheel_RPMs motor_data);
void send_to_pc(char* to_send);
void task2(wheel_RPMs motor_data);
void task3(wheel_RPMs motor_data);

#endif	/* SCHEDULER_H */

