/* 
 * File:   spi.h
 * 
 * Author: Alice Maria Catalano(5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 *
 */

#ifndef SPI_H
#define	SPI_H

#define FIRST_ROW 0
#define SECOND_ROW 1

void  spi_config();

// Function used to write a character on LCD
void put_char_SPI(char c);

// Function used to write a string on LCD
void write_string_LCD(char* str);

void move_cursor(int row, int column);

// Function used to clear the rows
void clear_LCD_firstRow();
void clear_LCD_secondRow();


#endif	/* SPI_H */

