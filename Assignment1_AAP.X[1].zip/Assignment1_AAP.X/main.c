/*
 * File: main.c
 * Author: Alice Catalano (5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 * Date: 20/11/2022
 * 
 * 1. Simulate an algorithm that needs 7 ms for its execution, and
needs to work at 100 Hz.
2. Read characters from UART and display the characters received
on the first row of the LCD.
3. When the end of the row has been reached, clear the first row
and start writing again from the first row first column
4. Whenever a CR ?nr? or LF ?nn? character is received, clear the first
row
5. On the second row, write ?Char Recv: XXX?, where XXX is the
number of characters received from the UART2. (use
sprintf(buffer, ?%d?, value) to convert an integer to a string to be
displayed
6. Whenever button S5 is pressed, send the current number of chars
received to UART2
7. Whenever button S6 is pressed, clear the first row and reset the
characters received counter
 */

#include "xc.h"
#include <stdio.h>
#include <stdlib.h>
#include "assignment.h"
#include <xc.h>
#include <p30F4011.h>
// FOSC
#pragma config FPR = XT                 // Primary Oscillator Mode (XT)
#pragma config FOS = PRI                // Oscillator Source (Primary Oscillator)
#pragma config FCKSMEN = CSW_FSCM_OFF   // Clock Switching and Monitor (Sw Disabled, Mon Disabled)

// FWDT
#pragma config FWPSB = WDTPSB_16        // WDT Prescaler B (1:16)
#pragma config FWPSA = WDTPSA_512       // WDT Prescaler A (1:512)
#pragma config WDT = WDT_OFF            // Watchdog Timer (Disabled)

// FBORPOR
#pragma config FPWRT = PWRT_64          // POR Timer Value (64ms)
#pragma config BODENV = BORV20          // Brown Out Voltage (Reserved)
#pragma config BOREN = PBOR_ON          // PBOR Enable (Enabled)
#pragma config LPOL = PWMxL_ACT_HI      // Low-side PWM Output Polarity (Active High)
#pragma config HPOL = PWMxH_ACT_HI      // High-side PWM Output Polarity (Active High)
#pragma config PWMPIN = RST_IOPIN       // PWM Output Pin Reset (Control with PORT/TRIS regs)
#pragma config MCLRE = MCLR_EN          // Master Clear Enable (Enabled)

// FGS
#pragma config GWRP = GWRP_OFF          // General Code Segment Write Protect (Disabled)
#pragma config GCP = CODE_PROT_OFF      // General Segment Code Protection (Disabled)

// FICD
#pragma config ICS = ICS_PGD 


#define FIRST_ROW 0
#define SECOND_ROW 1
#define BUFFER_SIZE 60


int cursor_count=0;              //position of the cursor
int character_count=0;           // characters received from UART2
char string[16];                //string global variable

typedef struct {
    char buffer[BUFFER_SIZE];
    int readIndex;
    int writeIndex;
} 

CircularBuffer;
volatile CircularBuffer cb;
int buttonS6flag = 0;


//function used to set the prescaler
int choose_prescaler(int ms,int* pr,int* tckps) {
    
    long ticks= 1843.2 * ms; //clock freql
    
    if(ticks<=65535)
    {
        *tckps=0;
        *pr=ticks;
        return 0;
    }
    //prescaler 1:8
    ticks=ticks/8;
    if(ticks<=65535)
    {
        *tckps=1;
        *pr=ticks;
        return 0;
    }
    //prescaler 1:64
    ticks=ticks/64;
    if(ticks<=65535)
    {
        *tckps=2;
        *pr=ticks;
        return 0;
    }
    //prescaler 1:256
    ticks=ticks/256;
    if(ticks<=65535)
    {
        *tckps=3;
        *pr=ticks;
        return 0;
    }
    return 1;
}

//set and wait into the same function
int tmr_wait(int timer, int ms) {
    switch (timer){
        case TIMER1:
        {
            int pr,tckps;
            choose_prescaler(ms, &pr, &tckps);
            PR1=pr;
            T1CONbits.TCKPS = tckps;
            T1CONbits.TCS = 0;
            T1CONbits.TGATE = 0;

            T1CONbits.TON = 0;
            IFS0bits.T1IF = 0;
            TMR1 = 0;
            T1CONbits.TON = 1;
            while (IFS0bits.T1IF == 0);
                IFS0bits.T1IF = 0;
                T1CONbits.TON = 0;
            break;
        }
        case TIMER2:
        {
            int pr,tckps;
            choose_prescaler(ms, &pr, &tckps);
            PR2=pr;
            T2CONbits.TCKPS = tckps;
            T2CONbits.TCS = 0;
            T2CONbits.TGATE = 0;

            T2CONbits.TON = 0;
            IFS0bits.T2IF = 0;
            TMR2 = 0;
            T2CONbits.TON = 1;
            while (IFS0bits.T2IF == 0);
            IFS0bits.T2IF = 0;
            T2CONbits.TON = 0;
            break;
        }
    }
    return 0;
}

//function used to set timer for a specific time in ms
void tmr_setup_period(int timer,int ms) {

    switch(timer){
        case TIMER1:
        {
            int pr,tckps;
            choose_prescaler(ms,&pr,&tckps);
            PR1=pr;                             //set the count
            T1CONbits.TCKPS=tckps;              // set the prescaler
            T1CONbits.TCS=0;                    //set the internal clock
            T1CONbits.TGATE=0;
            TMR1=0;                             //reset timer 1
            T1CONbits.TON=1;                    //start the timer
            break;
        }
        case TIMER2:
        {
            int pr,tckps;
            choose_prescaler(ms,&pr,&tckps);
            PR2=pr;                             //set the count
            T2CONbits.TCKPS=tckps;              // set the prescaler
            T2CONbits.TCS=0;                    //set the internal clock
            T2CONbits.TGATE=0;
            TMR2=0;                             //reset timer 2
            T2CONbits.TON=1;                    //start the timer
            break;
        }
    }
}

//once setted the timer wait for the flag
int tmr_wait_period(int timer) {
    switch(timer){
        case TIMER1:
        {
            if(IFS0bits.T1IF==1){               //If when enter the timer is already expires
                IFS0bits.T1IF=0;                //Set the flag to zero and return error
                return 1;
            }
            while(IFS0bits.T1IF==0);
            IFS0bits.T1IF=0;
            break;
        }
        case TIMER2:
        {
            if(IFS0bits.T2IF==1){               //If when enter the timer is alreadu expires
                IFS0bits.T2IF=0;                //Set the flag to zero and return error
                return 1;
            }
            while(IFS0bits.T2IF==0);            //stay into the while until timer expires
            IFS0bits.T2IF=0;
            break;
        }
    }
    return 0;
}

//SPI setup
void  spi_config() {
    SPI1CONbits.PPRE = 3;  
    SPI1CONbits.SPRE = 6; 
    SPI1CONbits.MSTEN = 1; 
    SPI1CONbits.MODE16 = 0; 
    SPI1STATbits.SPIEN = 1; 
}

//function to put a character into SPI
void put_char_SPI(char c){
    while(SPI1STATbits.SPITBF == 1); //polling until SPI buffer ready
    SPI1BUF = c;
}

// SPI interaction with LCD 
void write_string_LCD(char* str){
    int i;
    for( i = 0; str[i] != '\0'; i++){
        put_char_SPI(str[i]);
    }
}

void move_cursor(int row, int column){          //giving the row and column for the function
    switch(row){
        case 0:{
            put_char_SPI(0x80 + column);        // 0x80 represents the 1st row of the LCD
            return;
        }
        case 1:{
            put_char_SPI(0xC0 + column);        //0xc0 represents the 2nd row
            return;
        }
    }
}

void clear_LCD(){
    move_cursor(FIRST_ROW, 0);
    int i = 0;
    for(i = 0; i < 16; i++){
        put_char_SPI(' ');                      //write spaces to clear the LCD from previous char
    }
}

void write_buffer(volatile CircularBuffer* cb, char value){
    cb ->buffer[ cb -> writeIndex] = value;
    cb -> writeIndex++;
    if(cb -> writeIndex == BUFFER_SIZE)
        cb -> writeIndex = 0;
}

int read_buffer(volatile CircularBuffer *cb, char *value ){
    if(cb -> readIndex == cb -> writeIndex)
        return 0;
    
    *value = cb -> buffer[cb -> readIndex];
    cb -> readIndex++;
    if(cb -> readIndex == BUFFER_SIZE)
        cb -> readIndex = 0;
    return 1;
}

//ISR for the UART2 
void __attribute__((__interrupt__,__auto_psv__)) _U2RXInterrupt(){
    IFS1bits.U2RXIF = 0;                                            //reset the flag
    character_count++;
    char val = U2RXREG;                                             //take the char from UART register
    write_buffer(&cb, val);                                         // put it in the circular buffer
}

//ISR when S5 is pressed
void __attribute__((__interrupt__,__auto_psv__)) _INT0Interrupt(){
    IFS0bits.INT0IF = 0;                                            //reset the flag
    U2TXREG = character_count;                                      //transmitting to UART2
}

// ISR when S6 is pressed
void __attribute__((__interrupt__,__auto_psv__)) _INT1Interrupt(){
    IFS1bits.INT1IF = 0;                                            //reset the flag
    clear_LCD();                                                    //clear the first row
    buttonS6flag = 1;                                               //set the flag as high for button S6
    character_count = 0;                                            //reset the counter
}

//main function
int main(void) {
   
    //first need to wait 1 second
    tmr_wait(TIMER1, 1000);   

    cb.writeIndex = 0;
    cb.readIndex = 0;                                    
    TRISEbits.TRISE8 = 1;                   //button S5 as input                                
    TRISDbits.TRISD0 = 1;                   //button S6 as input                                                                                   //
                                                                                                                                                                                                                 
    //UART2 Initialization                                                   
    U2BRG = 11;                             // (7372800 / 4) / (16 * 9600)-1   
    U2MODEbits.STSEL = 0;                   // 1 stop bit                                       
    U2MODEbits.PDSEL = 1;                   // 8 bit no parity                               
    U2MODEbits.UARTEN = 1;                  // UART enable                                                                                                             //
    U2STAbits.UTXEN = 1;                    // enable transmission                              
   
    //enabling interrupts
    IEC1bits.U2RXIE = 1;                    //enable interrupt for UART2 reception             
    IEC0bits.INT0IE = 1;                    //enable interrupt for button S5                   
    IEC1bits.INT1IE = 1;                    //enable interrupt for button S6                   
    
    //Put the cursor on the second row, column 0 to put the string char rev without overwriting on it
    move_cursor(SECOND_ROW,0);
    write_string_LCD("Char Recv:");
    
    //call the algorithm 
    algorithm_called();
    
    while(1) {
        tmr_setup_period(TIMER1, 10);
        tmr_wait(TIMER2, 7);
        
        IEC1bits.U2RXIE = 0;                        //Disable interrupt UART2
        
        char value;                                 // value coming from the buffer
        int read = read_buffer(&cb, &value);        //reading from the buffer
        
        //Read the circular buffer
        if(read == 1){        
            move_cursor(FIRST_ROW, cursor_count);
            
            //if the character is \r or the character is \n or the the row ended clear 1st row
            if((value=='\r') || (value=='\n') || (cursor_count==15)){
                clear_LCD();
                cursor_count=0;
            }
            //else write on SPI
            else{
                put_char_SPI(value);  
                cursor_count++;                      //counting numbers of characters
                  
            }
        }
        
        move_cursor(SECOND_ROW, 11);                //write on the second row 1st col
        sprintf(string, "%d", value);               // write "Char recv:"
        write_string_LCD(string);                   //sending the string to be counted
        
        //if the button S6 is pressed
        if(buttonS6flag == 1){
            buttonS6flag = 0;
        } 
        //enable interrupt UART2      
        IEC1bits.U2RXIE = 1;
               
        tmr_wait_period(TIMER1);
    }

    return 0;
}