/*
 * File: main.c
 * Author: Alice Catalano (5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 * Date: 20/11/2022
 */

#ifndef ASSIGNMENT_H
#define ASSIGNMENT_H

#define TIMER1 1
#define TIMER2 2  

#define FIRST_ROW 0
#define SECOND_ROW 1

//function for the algorithm
void algorithm_called();

//function to set and wait ms
int tmr_wait(int timer, int ms);

//function used to set the prescaler
int choose_prescaler(int ms,int* pr,int* tckps);

//set the timer for ms
void tmr_setup_period(int timer, int ms);

//wait until the timer expires
int tmr_wait_period(int timer);

//function used to write a character on LCD
void spi_put_char(char c);

//function used to write a string on LCD
void spi_put_string(char* str);

//function used to move the cursor
void spi_move_cursor(int row, int column);

//function used to clear the first row
void spi_clear_first_row();

#endif	/*ASSIGNMENT_H */
