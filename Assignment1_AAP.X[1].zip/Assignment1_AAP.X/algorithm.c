/*
 * File: main.c
 * Author: Alice Catalano (5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 * Date: 20/11/2022
 */

#include "xc.h"
#include "assignment.h"



int algorithm(void) {
    
    algorithm_called();
    return 0;
}

void algorithm_called()
{
    tmr_setup_period(TIMER1, 10);
    
    if(IFS0bits.T1IF==1){ //If when enter the timer is already expires
        IFS0bits.T1IF=0; //Set the flag to zero and return error
        return;
    }
    
    tmr_wait(TIMER1, 7);
    
    while(IFS0bits.T1IF==0);
    IFS0bits.T1IF=0;
}

