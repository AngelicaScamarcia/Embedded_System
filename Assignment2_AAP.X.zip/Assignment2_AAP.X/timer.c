/*
 * File:   timer.c 
 * Author: Alice Maria Catalano(5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 *
 * Submitted on 14 Dicembre 2022
 */

#include "xc.h"
#include "timer.h"

void choose_prescaler(int ms, int* pr, int* tckps){
    //Fosc= 7.3728 MHz
    //Fcy = 7.3728/4=1843200 Hz
    
    long ticks= 1843.2 * ms; //long because the multiplication can overflow
    
    if (ticks <=65535) {
        //prescaler 1:1
        *pr= ticks;
        *tckps= 0;
        return;
    }
    
    ticks=ticks/8;
    if (ticks <=65535) {
        //prescaler 1:8
        *pr= ticks;
        *tckps= 1;
        return;
    }
    
    ticks=ticks/8;
    if (ticks <=65535) {
        //prescaler 1:16
        *pr= ticks;
        *tckps= 2;
        return;
    }
    
    ticks=ticks/4;
    if (ticks <=65535) {
        //prescaler 1:256
        *pr= ticks;
        *tckps= 2;
        return;
    }
}

void tmr_setup_period(int timer, int ms){
    int pr;
    int tckps;
    if(timer == TIMER1){
        T1CONbits.TON = 0;
        TMR1 = 0;
        choose_prescaler(ms, &pr, &tckps);
        T1CONbits.TCKPS= tckps;
        PR1 = pr;
        T1CONbits.TON = 1;
    }else if(timer == TIMER2){
        T2CONbits.TON = 0;
        TMR2 = 0;
        choose_prescaler(ms, &pr, &tckps);
        T2CONbits.TCKPS= tckps;
        PR2 = pr;
        T2CONbits.TON = 1;
    }else if(timer == TIMER3){
        T3CONbits.TON = 0;
        TMR3 = 0;
        choose_prescaler(ms, &pr, &tckps);
        T3CONbits.TCKPS= tckps;
        PR3 = pr;
        T3CONbits.TON = 1;
    }      
}

void tmr_wait_period(int timer){
    
    if(timer == TIMER1){
        while(IFS0bits.T1IF == 0);
        IFS0bits.T1IF = 0;
        return;
    }else if(timer == TIMER2){
        while(IFS0bits.T2IF == 0);
        IFS0bits.T2IF = 0;
        return;
    }else if(timer == TIMER3){
        while(IFS0bits.T3IF == 0);
        IFS0bits.T3IF = 0;
        return;
    }
}

void tmr_wait_ms(int timer, int ms) {
    switch (timer) {
        case TIMER1:
        {
            int pr, tckps;
            choose_prescaler(ms, &pr, &tckps);
            PR1 = pr;
            T1CONbits.TCKPS = tckps;
            T1CONbits.TCS = 0;
            T1CONbits.TGATE = 0;
            
            T1CONbits.TON = 0;
            IFS0bits.T1IF = 0;
            TMR1 = 0;
            
            T1CONbits.TON = 1;
            while(IFS0bits.T1IF == 0);
            IFS0bits.T1IF = 0;
            T1CONbits.TON = 0;
            break;
        }
        case TIMER2:
        {
            int pr, tckps;
            choose_prescaler(ms, &pr, &tckps );
            PR2 = pr;
            T2CONbits.TCKPS = tckps;
            T2CONbits.TCS = 0;
            T2CONbits.TGATE = 0;
            
            T2CONbits.TON = 0;
            IFS0bits.T2IF = 0;
            TMR2 = 0;
            
            T2CONbits.TON = 1;
            while(IFS0bits.T2IF == 0);
            IFS0bits.T2IF = 0;
            T2CONbits.TON = 0;
            break;
        }
        case TIMER3:
        {
            int pr, tckps;
            choose_prescaler(ms, &pr, &tckps );
            PR3 = pr;
            T3CONbits.TCKPS = tckps;
            T3CONbits.TCS = 0;
            T3CONbits.TGATE = 0;
            
            T3CONbits.TON = 0;
            IFS0bits.T3IF = 0;
            TMR3 = 0;
            
            T3CONbits.TON = 1;
            while(IFS0bits.T3IF == 0);
            IFS0bits.T3IF = 0;
            T3CONbits.TON = 0;
            break;
        }
           
    }
}
