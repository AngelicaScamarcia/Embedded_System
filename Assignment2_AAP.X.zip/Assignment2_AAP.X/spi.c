/*
 * File:   spi.c 
 * Author: Alice Maria Catalano(5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 *
 * Submitted on 14 Dicembre 2022
 */

#include "xc.h"
#include <stdio.h>
#include <stdlib.h>
#include "spi.h"
#include "timer.h"
#include <xc.h>
#include <p30F4011.h>

#define FIRST_ROW 0
#define SECOND_ROW 1

//SPI setup
void  spi_config() {
    SPI1CONbits.PPRE = 3; //2  
    SPI1CONbits.SPRE = 6; //7
    SPI1CONbits.MSTEN = 1; 
    SPI1CONbits.MODE16 = 0; 
    SPI1STATbits.SPIEN = 1; 
}

//function to put a character into SPI
void put_char_SPI(char c){
    while(SPI1STATbits.SPITBF == 1); //polling until SPI buffer ready
    SPI1BUF = c;
}

// SPI interaction with LCD 
void write_string_LCD(char* str){
    int i;
    for( i = 0; str[i] != '\0'; i++){
        put_char_SPI(str[i]);
    }
}

void move_cursor(int row, int column){          //giving the row and column for the function
    switch(row){
        case 0:{
            put_char_SPI(0x80 + column);        // 0x80 represents the 1st row of the LCD
            return;
        }
        case 1:{
            put_char_SPI(0xC0 + column);        //0xc0 represents the 2nd row
            return;
        }
    }
}

void clear_LCD_firstRow(){
    move_cursor(FIRST_ROW, 0);
    int i = 0;
    for(i = 0; i < 16; i++){
        put_char_SPI(' ');                      //write spaces to clear the LCD from previous char
    }
}

void clear_LCD_secondRow(){
    move_cursor(SECOND_ROW, 0);
    int i = 0;
    for(i = 0; i < 16; i++){
        put_char_SPI(' ');                      //write spaces to clear the LCD from previous char
    }
}
