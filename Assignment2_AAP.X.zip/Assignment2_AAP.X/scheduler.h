/* 
 * File:   scheduler.h
 * Author: pesci
 *
 * Created on 16 dicembre 2022, 14.38
 */

#ifndef SCHEDULER_H
#define	SCHEDULER_H

#define MAX_TASKS 3

typedef struct {
    int n;
    int N;
} heartbeat;
heartbeat schedInfo[MAX_TASKS];

typedef struct{
    double current;
    double temperature;
}data_sensors_t;
data_sensors_t data_sensors;

void scheduler() ;
void scheduler_config();
data_sensors_t send_to_micro(parser_state*, data_sensors_t);
void send_to_pc(data_sensors_t);
void blink_led();

#endif	/* SCHEDULER_H */

