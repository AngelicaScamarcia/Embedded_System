/*
 * File:   main.c

 * Author: Alice Maria Catalano(5157341), Angelica Scamarcia (5290802), Pia Saade (5244966)
 *
 * Submitted on 14 Dicembre 2022
 */

// DSPIC30F4011 Configuration Bit Settings

// 'C' source line config statements

// FOSC
#pragma config FPR = XT                 // Primary Oscillator Mode (XT)
#pragma config FOS = PRI                // Oscillator Source (Primary Oscillator)
#pragma config FCKSMEN = CSW_FSCM_OFF   // Clock Switching and Monitor (Sw Disabled, Mon Disabled)

// FWDT
#pragma config FWPSB = WDTPSB_16        // WDT Prescaler B (1:16)
#pragma config FWPSA = WDTPSA_512       // WDT Prescaler A (1:512)
#pragma config WDT = WDT_OFF            // Watchdog Timer (Disabled)

// FBORPOR
#pragma config FPWRT = PWRT_64          // POR Timer Value (64ms)
#pragma config BODENV = BORV20          // Brown Out Voltage (Reserved)
#pragma config BOREN = PBOR_ON          // PBOR Enable (Enabled)
#pragma config LPOL = PWMxL_ACT_HI      // Low-side PWM Output Polarity (Active High)
#pragma config HPOL = PWMxH_ACT_HI      // High-side PWM Output Polarity (Active High)
#pragma config PWMPIN = RST_IOPIN       // PWM Output Pin Reset (Control with PORT/TRIS regs)
#pragma config MCLRE = MCLR_EN          // Master Clear Enable (Enabled)

// FGS
#pragma config GWRP = GWRP_OFF          // General Code Segment Write Protect (Disabled)
#pragma config GCP = CODE_PROT_OFF      // General Segment Code Protection (Disabled)

// FICD
#pragma config ICS = ICS_PGD            // Comm Channel Select (Use PGC/EMUC and PGD/EMUD)

#include <xc.h>
#include <p30F4011.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.h"
#include "scheduler.h"
#include "timer.h"


#define BUFFER_SIZE_1 12                                                        //the message is 11 char, but if the user inserts 1000 goes to 12
#define BUFFER_SIZE_2 18                                                        // the message should reach 17 char

int rpm_flag = 0;
int overflow_flag = 0;

typedef struct {
    int size;
    int readIndex;
    int writeIndex;
    char buffer[];
}

CircularBuffer;
volatile CircularBuffer circularBuffer;                                         
volatile CircularBuffer cb_output;

void write_buffer(volatile CircularBuffer* cb, char value){
    cb ->buffer[ cb -> writeIndex] = value;
    cb -> writeIndex = (cb -> writeIndex + 1) % cb->size;                       // if the writeIndex goes to 12 or 18, it will be not allowed and it will go back to 0
    if(cb -> readIndex == cb -> writeIndex){
        //full buffer mode
        cb ->readIndex++;                                                       //discard the last byte
    }
}

void read_buffer(volatile CircularBuffer* cb, char* value ){
    if(cb -> readIndex != cb -> writeIndex) {
        *value = cb -> buffer[cb -> readIndex];
        cb -> readIndex = (cb->readIndex +1) % cb->size;
    }
}

int avl_bytes_cb(volatile CircularBuffer* cb){                                  //to check how many bytes are in the buffer
    if(cb -> readIndex <= cb -> writeIndex) {                                   //might give problems with interrupts on one of the indexes
        return cb->writeIndex - cb -> readIndex;                                //if the readInd is less than the writeInd , then the number of bytes is the difference between them
    }else{
        return cb->size - cb ->readIndex + cb->writeIndex;
    }
}

//ADC setup
void adc_config(){
    //ADC configuration
    // first select the ADCS 
    ADCON3bits.ADCS = 32;         // Tad
    
    ADCON1bits.ASAM = 1;          // automatic sampling start
    ADCON1bits.SSRC = 7;          // automatic conversion start
    
    ADCON3bits.SAMC = 31;         //fixed conversion time (only if SSRC = 7)
    
    ADCON2bits.CHPS = 0b01;          // ch0 and ch1
    //select the input positive 
    ADCHSbits.CH0SA = 0b10;          //because we use an2, AN2 connected to CH0
    
    ADCHSbits.CH123SA = 0b1;        //AN3 connected to CH1
   
    ADPCFG = 0xFFFF;      
    ADPCFGbits.PCFG2 = 0;         
    ADPCFGbits.PCFG3 = 0;         
    //Turn on
    ADCON1bits.ADON =1;
}

// ADC calculation
void set_adc_volt(double* c, double* t){
    while(ADCON1bits.DONE == 0);                                                //Wait until the conversion is complete
        
    int adcValuePot = ADCBUF0;                                        
    int adcValueTemp = ADCBUF1;
        
    double PotVolt = adcValuePot / 1024.0 * 5.0;
    double TempVolt = adcValueTemp / 1024.0 * 5.0;
     //compute the current
    *c = 10 * (PotVolt - 3);                                                    //-3 because there's the offset at 0V of 3A
                                                 
    // convert voltage in temperature    1 Vol = 100 deg
    *t = (TempVolt -0.75) * 100 + 25;                                           //0.75 is the delta in voltage wrt 25 deg
}

//UART
void send_string_uart(char* string){    //from micro to pc
    int i;
    for(i = 0; string[i] != '\0'; i++) {
        while(U2STAbits.UTXBF == 1);
        U2TXREG = string[i];
    }
}

//Scheduler
void scheduler_config(){
    schedInfo[0].n = 0;
    schedInfo[0].N = 1;     //heartbeat 200Hz
    schedInfo[1].n = 0;
    schedInfo[1].N = 200;   // send the current and temperature at 1Hz, 200*5= 1000 Hz
    schedInfo[2].n = 0;
    schedInfo[2].N = 100;   // turn led on/off in 1Hz, so 500ms on and 500ms off so the value will be the half of before
}

//ISF for UART2 receiving
void __attribute__((__interrupt__,__auto_psv__)) _U2RXInterrupt(){              //receiver interrupt, it will interrupt whenever it gets a character.
    IFS1bits.U2RXIF = 0;
    while(U2STAbits.URXDA == 1) {
        write_buffer(&circularBuffer, U2RXREG);
    }
    if(U2STAbits.OERR == 1){
        overflow_flag = 1;
    }
}   

//ISF for UART2 transmitting
void __attribute__((__interrupt__,__auto_psv__)) _U2TXInterrupt(){
    IFS1bits.U2TXIF = 0;
    int available_bytes_output= avl_bytes_cb(&cb_output);
    char feedback;
    while(U2STAbits.UTXBF != 1 && available_bytes_output!=0){
        read_buffer(&cb_output, &feedback);
        U2TXREG=feedback;
        available_bytes_output= avl_bytes_cb(&cb_output);
    }
}

//Task 1
data_sensors_t send_to_micro(parser_state* pstate, data_sensors_t data_sensors){
    
    double duty_cycle;
    int available_bytes;
    
    IEC1bits.U2RXIE = 0;                                                        // Protecting the function from the interrupts
    available_bytes= avl_bytes_cb(&circularBuffer);                             // Compute how many data in the buffer
    IEC1bits.U2RXIE = 1;
        
    int count = 0;
    while (count < available_bytes) {
        char byte;
            
        read_buffer(&circularBuffer, &byte);                                    // Bytes that I can give to the parser
        
        int ret = parse_byte(pstate, byte); 
        if (ret == NEW_MESSAGE) {                                               // Check the arrival of a complete message
            int rpm;                                                            // Value going from 0 to 1000
            
            //The PC sends $MCREF,RPM*, where RPM is a value going from 0 to 1000
            if(strcmp(pstate->msg_type, "MCREF" )==0) {                         
                rpm = extract_integer(pstate->msg_payload);
                if(rpm >0 && rpm < 1000){
                    //calculate the  duty cycle based on the rpm of the motor
                    duty_cycle = 0.001 * rpm;
                    //apply the PWM
                    PDC2 = duty_cycle * 2 * PTPER;
                }else{
                    rpm_flag = 1;
                }
            } 
        }count ++;
    }
    //AD conversion
    set_adc_volt(&data_sensors.current, &data_sensors.temperature);
    if (data_sensors.current > 15.0){                                                    
        LATBbits.LATB1 = 1;                                                     // Turn on LED D4                                                 
    }else{                                                                
        LATBbits.LATB1 = 0;                                                     // Turn off LED D4                                               
    }
    return data_sensors;
}

//Task 2
void send_to_pc(data_sensors_t data_sensors){
    
    int available_bytes_output;
   
    // build the message for the UART   $MCFBK,CURRENT,TEMP* 
        
    char msg_type[25] = "$MCFBK,";
    char str[17]; //strings to print
        
    sprintf(str,"%.1f,%.1f", data_sensors.current, data_sensors.temperature);
    strcat(msg_type,str);
    strcat(msg_type,"*");
        
    IEC1bits.U2TXIE = 0;                                                        // Protecting the function from the interrupts
    available_bytes_output= BUFFER_SIZE_2 -avl_bytes_cb(&cb_output);            // Compute how many data are free in the buffer
    IEC1bits.U2TXIE = 1;
        
    char feedback;
    if(strlen(str) < available_bytes_output) {
        for(int i = 0; i<strlen(msg_type); i++){
            write_buffer(&cb_output, msg_type[i]);
        }
        IEC1bits.U2TXIE=0;
        while(U2STAbits.UTXBF == 0){
            read_buffer(&cb_output, &feedback);
            U2TXREG=feedback;
        }
        IEC1bits.U2TXIE=1;
    }
}

//Task 3
void blink_led(){
    if(rpm_flag == 0){
        LATBbits.LATB0 = !LATBbits.LATB0;
    }else{
        LATBbits.LATB0 = 0;
    }
    if (overflow_flag == 1){
        U2STAbits.OERR = 0;
        LATBbits.LATB0 = 0;
    }
   
}

int main(void){
    //tmr_wait_ms(TIMER1, 1000); // wait 1 second
    
    TRISBbits.TRISB0 = 0;
    TRISBbits.TRISB1 = 0;
    
    // Initialize the circular buffers
    circularBuffer.size = BUFFER_SIZE_1;
    circularBuffer.readIndex=0;
    circularBuffer.writeIndex=0;
    cb_output.size = BUFFER_SIZE_2;
    cb_output.readIndex=0;
    cb_output.writeIndex=0;
    
    adc_config();
    
    //baud rate (73728/4) / (16*9600) = 12 -1 = 11
    U2BRG = 11;             
    U2MODEbits.UARTEN = 1;
    U2STAbits.UTXEN = 1; 
    U2STAbits.UTXISEL = 0b1;                                                    // interrupt when transmit buffer becomes empty
    U2STAbits.URXISEL = 0b00;                                                   // interrupt when a character is received 
    IEC1bits.U2RXIE =1;                                                         // Interrupt enabled, data will arrive and put in the buffer
    IEC1bits.U2TXIE = 1;                                                        // enable transmitter interrupt 
    
    // PWM initialization
    PTCONbits.PTMOD = 0;                                                        // Free running
    PTCONbits.PTCKPS = 0;                                                       // 1:1 prescaler
    PWMCON1bits.PEN2H = 1;
    PTPER = 1842;
    PTCONbits.PTEN = 1;
    
    // parser initialization
    parser_state pstate;
	pstate.state = STATE_DOLLAR;
	pstate.index_type = 0; 
	pstate.index_payload = 0;
    
    scheduler_config();
    tmr_setup_period(TIMER1, 5);
    
    while(1){
        int i ;
        for (i = 0; i < MAX_TASKS; i++) {
            schedInfo[i]. n++;
            if (schedInfo[i]. n >= schedInfo[i].N) {
                switch(i) {
                    case 0:
                        //read the rpm value and compute the ad conversion;
                        data_sensors = send_to_micro(&pstate, data_sensors);
                        
                        break;
                    case 1:
                        send_to_pc(data_sensors);
                        break;
                    case 2:
                        blink_led();
                        break;
                }
                schedInfo[i]. n = 0;
            }
        }
        tmr_wait_period(TIMER1);
    }
    return 0;
}

